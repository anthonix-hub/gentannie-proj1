from django.urls import path, include
from . import views

urlpatterns = [
    path('client_data_input', views.client_data_input, name='client_data_input')
]
