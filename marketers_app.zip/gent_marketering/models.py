from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

locked = 'locked'
unlocked = 'unlocked'
type = [(locked, 'locked'), (unlocked, 'unlocked')]

class marketer001_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    amount = models.CharField(max_length=20)
    account_type = models.CharField(max_length=30, choices=type)
    models.DateField(auto_now_add=True)

class marketer002_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    models.DateField(auto_now_add=True)

class marketer003_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer004_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer005_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer006_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer007_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer008_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer009_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer010_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer011_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer012_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer013_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer014_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer015_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer016_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer017_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer018_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer019_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)

class marketer020_client(models.Model):
    clients_username = models.CharField(max_length=40)
    other_names = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=11)
    account_type = models.CharField(max_length=30, choices=type)
    amount = models.CharField(max_length=20)
    date_created = models.DateField(auto_now_add=True)
