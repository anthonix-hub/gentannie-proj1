from django.apps import AppConfig


class GentMarketeringConfig(AppConfig):
    name = 'gent_marketering'
