from django.shortcuts import render


def client_data_input(request):

    return render(request, 'gent_marketering/index.html', None)

