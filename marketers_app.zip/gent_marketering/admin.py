from django.contrib import admin
from .models import (  
    marketer001_client,marketer002_client,
    marketer003_client,
    marketer004_client, marketer005_client,
    marketer006_client, marketer007_client,
    marketer008_client, marketer009_client,
    marketer010_client,marketer011_client,
    marketer012_client,marketer013_client,
    marketer014_client,marketer015_client,
    marketer016_client,marketer017_client,
    marketer018_client,marketer019_client,
    marketer020_client
)

class marketer001_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer002_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer003_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer004_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer005_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer006_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer007_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer008_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer009_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer010_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer010_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer011_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer012_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer013_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer014_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer015_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer016_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer017_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer018_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer019_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

class marketer020_client_Admin(admin.ModelAdmin):
    list_display = ('clients_username', 'other_names', 'phone_number', 'amount', )

admin.site.register(marketer001_client,marketer001_client_Admin)
admin.site.register(marketer002_client,marketer002_client_Admin)
admin.site.register(marketer003_client,marketer003_client_Admin)
admin.site.register(marketer004_client,marketer004_client_Admin)
admin.site.register(marketer005_client,marketer005_client_Admin)
admin.site.register(marketer006_client,marketer006_client_Admin)
admin.site.register(marketer007_client,marketer007_client_Admin)
admin.site.register(marketer008_client,marketer008_client_Admin)
admin.site.register(marketer009_client,marketer009_client_Admin)
admin.site.register(marketer010_client,marketer010_client_Admin)
admin.site.register(marketer011_client,marketer011_client_Admin)
admin.site.register(marketer012_client,marketer012_client_Admin)
admin.site.register(marketer013_client,marketer013_client_Admin)
admin.site.register(marketer014_client,marketer014_client_Admin)
admin.site.register(marketer015_client,marketer015_client_Admin)
admin.site.register(marketer016_client,marketer016_client_Admin)
admin.site.register(marketer017_client,marketer017_client_Admin)
admin.site.register(marketer018_client,marketer018_client_Admin)
admin.site.register(marketer019_client,marketer019_client_Admin)
admin.site.register(marketer020_client,marketer020_client_Admin)

